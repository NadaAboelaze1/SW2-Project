@extends('admin.layouts.branch_admin_app')
@section('content')
    <h1>HELLO Branch admin</h1>
@endsection
@extends('admin.layouts.cashier_app')
@section('content')
    <h1>HELLO CASHIER</h1>
@endsection
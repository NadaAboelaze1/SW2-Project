
@include('admin.layouts.parts.cashier_sidebar')
@include('admin.layouts.parts.header')



@include('admin.layouts.parts.footer')



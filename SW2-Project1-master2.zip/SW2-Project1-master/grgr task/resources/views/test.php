<?php

var_dump(class_exists('PDO'));

// Or
var_dump(defined(PDO::MYSQL_ATTR_LOCAL_INFILE)); // mysql

// Or
var_dump(extension_loaded ('PDO' )); // returns boolean

// Or
var_dump(extension_loaded('pdo_mysql'));

// Or get all extensions and search for a specific one
var_dump(get_loaded_extensions()); 
?>
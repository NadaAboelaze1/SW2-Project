<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class esraa extends Model
{
    //
}
